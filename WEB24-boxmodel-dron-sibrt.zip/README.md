BoxModel DJI Mini
